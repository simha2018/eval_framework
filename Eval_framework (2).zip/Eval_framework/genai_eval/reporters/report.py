"""
Report generation: JSON, Markdown, stdout summary.
"""
from __future__ import annotations

from pathlib import Path

from genai_eval.schemas.outputs import EvalReport


def print_summary(report: EvalReport) -> None:
    print(report.summary())


def save_json(report: EvalReport, path: str = "eval_report.json") -> None:
    Path(path).write_text(report.model_dump_json(indent=2), encoding="utf-8")
    print(f"  Saved: {path}")


def save_markdown(report: EvalReport, path: str = "eval_report.md") -> None:
    lines = [
        "# GenAI Eval Report",
        "",
        f"**Run ID:** `{report.run_id}`  ",
        f"**Judge:** `{report.judge_provider}/{report.judge_model}`  ",
        f"**Overall:** `{report.overall_score:.1%}` {'PASS' if report.passed else 'FAIL'}",
        "",
        "## Dimension Summary",
        "",
        "| Dimension | Score | Status | Samples |",
        "|-----------|------:|--------|--------:|",
    ]
    for dr in report.dimension_reports:
        status = "Pass" if dr.passed else "Fail"
        lines.append(f"| {dr.dimension} | {dr.overall_score:.1%} | {status} | {dr.num_samples} |")

    lines += ["", "## Metric Details", ""]
    for dr in report.dimension_reports:
        lines.append(f"### {dr.dimension}")
        for r in dr.metric_results:
            icon = "[PASS]" if r.passed else "[FAIL]"
            lines.append(f"- {icon} **{r.metric}**: `{r.score:.2f}` - {r.reasoning or ''}")
        lines.append("")

    Path(path).write_text("\n".join(lines), encoding="utf-8")
    print(f"  → Markdown saved: {path}")
