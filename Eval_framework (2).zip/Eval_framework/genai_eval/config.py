"""
EvalConfig — central configuration for the GenAI Eval Framework.
Switch judge between Claude and GPT without touching any other code.
"""
from __future__ import annotations

import os
from enum import Enum
from typing import List, Optional

from pydantic import BaseModel, Field, model_validator


class JudgeProvider(str, Enum):
    ANTHROPIC = "anthropic"
    OPENAI = "openai"


class EvalConfig(BaseModel):
    """
    Usage:

        # Default: Claude Sonnet as judge
        config = EvalConfig()

        # Switch to GPT-4o judge
        config = EvalConfig(judge_provider="openai")

        # Upgrade to Opus for higher-quality judging
        config = EvalConfig(anthropic_model="claude-opus-4-6")

        # Run only specific dimensions
        config = EvalConfig(active_dimensions=["rag", "agent", "safety"])
    """

    # ── Judge LLM ──────────────────────────────────────────────────────────────
    judge_provider: JudgeProvider = JudgeProvider.ANTHROPIC
    anthropic_model: str = "claude-sonnet-4-6"   # upgrade to claude-opus-4-6 for richer judging
    openai_model: str = "gpt-4o"
    judge_temperature: float = 0.0
    judge_max_tokens: int = 1024

    # ── API Keys (fall back to env vars ANTHROPIC_API_KEY / OPENAI_API_KEY) ───
    anthropic_api_key: Optional[str] = Field(default=None, exclude=True)
    openai_api_key: Optional[str] = Field(default=None, exclude=True)

    # ── Scoring ────────────────────────────────────────────────────────────────
    pass_threshold: float = 0.7   # score >= threshold → passed=True

    # ── Dimensions to run (None = all) ─────────────────────────────────────────
    active_dimensions: Optional[List[str]] = None

    @model_validator(mode="after")
    def _resolve_api_keys(self) -> "EvalConfig":
        if not self.anthropic_api_key:
            self.anthropic_api_key = os.getenv("ANTHROPIC_API_KEY")
        if not self.openai_api_key:
            self.openai_api_key = os.getenv("OPENAI_API_KEY")
        return self

    @property
    def active_judge_model(self) -> str:
        return self.anthropic_model if self.judge_provider == JudgeProvider.ANTHROPIC else self.openai_model

    class Config:
        use_enum_values = True
