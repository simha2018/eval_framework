"""
OpenAI (GPT) provider.
"""
from __future__ import annotations

from typing import List, Optional

from openai import AsyncOpenAI, OpenAI

from genai_eval.models.base import LLMProvider


class OpenAIProvider(LLMProvider):
    def __init__(
        self,
        model: str = "gpt-4o",
        api_key: Optional[str] = None,
        max_tokens: int = 1024,
        temperature: float = 0.0,
    ) -> None:
        self._model = model
        self._max_tokens = max_tokens
        self._temperature = temperature
        self._client = OpenAI(api_key=api_key)
        self._async_client = AsyncOpenAI(api_key=api_key)

    @property
    def model_name(self) -> str:
        return self._model

    def _msgs(self, prompt: str, system: Optional[str]) -> List[dict]:
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})
        return messages

    def complete(self, prompt: str, system: Optional[str] = None) -> str:
        resp = self._client.chat.completions.create(
            model=self._model,
            messages=self._msgs(prompt, system),
            max_tokens=self._max_tokens,
            temperature=self._temperature,
        )
        return resp.choices[0].message.content

    async def acomplete(self, prompt: str, system: Optional[str] = None) -> str:
        resp = await self._async_client.chat.completions.create(
            model=self._model,
            messages=self._msgs(prompt, system),
            max_tokens=self._max_tokens,
            temperature=self._temperature,
        )
        return resp.choices[0].message.content
