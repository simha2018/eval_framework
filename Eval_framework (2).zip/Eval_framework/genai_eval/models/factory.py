"""
Factory: build the right LLMProvider from EvalConfig.
"""
from __future__ import annotations

from genai_eval.config import EvalConfig, JudgeProvider
from genai_eval.models.anthropic_provider import AnthropicProvider
from genai_eval.models.base import LLMProvider
from genai_eval.models.openai_provider import OpenAIProvider


def build_provider(config: EvalConfig) -> LLMProvider:
    if config.judge_provider == JudgeProvider.ANTHROPIC:
        return AnthropicProvider(
            model=config.anthropic_model,
            api_key=config.anthropic_api_key,
            max_tokens=config.judge_max_tokens,
            temperature=config.judge_temperature,
        )
    return OpenAIProvider(
        model=config.openai_model,
        api_key=config.openai_api_key,
        max_tokens=config.judge_max_tokens,
        temperature=config.judge_temperature,
    )
