"""
Abstract base class for LLM providers.
Both AnthropicProvider and OpenAIProvider implement this interface,
so all judge logic is provider-agnostic.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Optional


class LLMProvider(ABC):
    @abstractmethod
    def complete(self, prompt: str, system: Optional[str] = None) -> str:
        """Synchronous completion — returns response text."""
        ...

    @abstractmethod
    async def acomplete(self, prompt: str, system: Optional[str] = None) -> str:
        """Async completion — returns response text."""
        ...

    @property
    @abstractmethod
    def model_name(self) -> str:
        """Model identifier string (e.g. 'claude-sonnet-4-6')."""
        ...
