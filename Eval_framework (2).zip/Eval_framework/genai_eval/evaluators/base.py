"""
Abstract base class for all dimension evaluators.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import List

from genai_eval.config import EvalConfig
from genai_eval.judges.llm_judge import LLMJudge
from genai_eval.schemas.outputs import DimensionReport, EvalResult


class BaseEvaluator(ABC):
    dimension: str = "base"

    def __init__(self, judge: LLMJudge, config: EvalConfig) -> None:
        self.judge = judge
        self.config = config

    @abstractmethod
    def evaluate(self, inputs: list) -> List[EvalResult]:
        """Run all metrics on inputs and return a flat list of EvalResult."""
        ...

    def report(self, results: List[EvalResult]) -> DimensionReport:
        return DimensionReport.from_results(
            dimension=self.dimension,
            results=results,
            judge_model=self.judge.provider.model_name,
            pass_threshold=self.config.pass_threshold,
        )

    def _result(self, metric: str, raw: dict) -> EvalResult:
        """Helper: build EvalResult from a judge.score() dict."""
        return EvalResult(
            metric=metric,
            score=float(raw.get("score", 0)),
            passed=bool(raw.get("passed", False)),
            reasoning=raw.get("reasoning"),
        )
