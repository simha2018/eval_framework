"""
LLM Quality evaluator.
"""
from __future__ import annotations

from typing import List

from genai_eval.evaluators.base import BaseEvaluator
from genai_eval.schemas.inputs import LLMQualityInput
from genai_eval.schemas.outputs import EvalResult


class LLMQualityEvaluator(BaseEvaluator):
    dimension = "llm_quality"

    def evaluate(self, inputs: List[LLMQualityInput]) -> List[EvalResult]:
        results: List[EvalResult] = []
        for inp in inputs:
            results.append(self._result("instruction_following", self.judge.score("instruction_following", {
                "prompt": inp.question, "response": inp.response,
            })))
            results.append(self._result("reasoning_quality", self.judge.score("reasoning_quality", {
                "question": inp.question, "response": inp.response,
            })))
            results.append(self._result("hallucination_rate", self.judge.score("hallucination_rate", {
                "context": inp.context or "(no context supplied)",
                "response": inp.response,
            })))
            if inp.ground_truth:
                results.append(self._result("correctness", self.judge.score("correctness", {
                    "question": inp.question,
                    "predicted_answer": inp.response,
                    "ground_truth": inp.ground_truth,
                })))
            if inp.response_variant:
                results.append(self._result("consistency", self.judge.score("consistency", {
                    "question": inp.question,
                    "response_1": inp.response,
                    "response_2": inp.response_variant,
                })))
        return results
