"""
Multi-Agent evaluator.
Metrics: e2e_task_success, routing_accuracy, handoff_quality,
         loop_detection (algorithmic), orchestrator_overhead (algorithmic)
"""
from __future__ import annotations

from typing import List

from genai_eval.evaluators.base import BaseEvaluator
from genai_eval.schemas.inputs import MultiAgentTrace
from genai_eval.schemas.outputs import EvalResult


class MultiAgentEvaluator(BaseEvaluator):
    dimension = "multi_agent"

    def evaluate(self, inputs: List[MultiAgentTrace]) -> List[EvalResult]:
        results: List[EvalResult] = []
        for trace in inputs:
            results.append(self._e2e_success(trace))
            results.append(self._routing_accuracy(trace))
            results.append(self._handoff_quality(trace))
            results.append(self._loop_detection(trace))
            results.append(self._orchestrator_overhead(trace))
        return results

    def _e2e_success(self, t: MultiAgentTrace) -> EvalResult:
        return self._result("e2e_task_success", self.judge.score("task_completion", {
            "task": t.task,
            "final_output": t.final_output,
            "expected_output": t.expected_output,
        }))

    def _routing_accuracy(self, t: MultiAgentTrace) -> EvalResult:
        return self._result("routing_accuracy", self.judge.score("routing_accuracy", {
            "task": t.task,
            "agent_calls": [{"agent": c.agent_name, "input_summary": c.input[:200]} for c in t.agent_calls],
        }))

    def _handoff_quality(self, t: MultiAgentTrace) -> EvalResult:
        handoffs = [
            {
                "from": t.agent_calls[i].agent_name,
                "to": t.agent_calls[i + 1].agent_name,
                "context_passed": t.agent_calls[i].output[:300],
            }
            for i in range(len(t.agent_calls) - 1)
        ]
        if not handoffs:
            return EvalResult(metric="handoff_quality", score=1.0, passed=True,
                              reasoning="Single agent call — no handoffs to evaluate.")
        return self._result("handoff_quality", self.judge.score("handoff_quality", {"handoffs": handoffs}))

    def _loop_detection(self, t: MultiAgentTrace) -> EvalResult:
        """Algorithmic: repeated (agent, input_prefix) tuples → loop."""
        seen: set = set()
        loops = 0
        for call in t.agent_calls:
            key = (call.agent_name, call.input[:80])
            if key in seen:
                loops += 1
            seen.add(key)
        score = max(0.0, 1.0 - loops * 0.33)
        return EvalResult(
            metric="loop_detection",
            score=round(score, 3),
            passed=loops == 0,
            reasoning=f"Detected {loops} loop(s) in agent call sequence.",
            metadata={"loop_count": loops},
        )

    def _orchestrator_overhead(self, t: MultiAgentTrace) -> EvalResult:
        """
        What fraction of total latency is sub-agent work vs. orchestration?
        High sub-agent share → low overhead → higher score.
        """
        total = sum(c.latency_ms for c in t.agent_calls) or 1.0
        sub_agent_ms = sum(
            c.latency_ms for c in t.agent_calls if c.agent_name != t.orchestrator
        )
        overhead = 1.0 - (sub_agent_ms / total)
        score = max(0.0, 1.0 - overhead)
        return EvalResult(
            metric="orchestrator_overhead",
            score=round(score, 3),
            passed=overhead <= 0.30,
            reasoning=f"Orchestrator consumed {overhead:.1%} of total latency.",
            metadata={"overhead_ratio": round(overhead, 3)},
        )
