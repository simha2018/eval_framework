"""
Knowledge Graph evaluator.
Metrics: kg_query_accuracy, entity_f1, relation_f1, schema_adherence
"""
from __future__ import annotations

from typing import List, Set

from genai_eval.evaluators.base import BaseEvaluator
from genai_eval.schemas.inputs import KGInput
from genai_eval.schemas.outputs import EvalResult


def _f1(predicted: List[str], expected: List[str]) -> float:
    if not expected:
        return 1.0 if not predicted else 0.0
    if not predicted:
        return 0.0
    pred_set: Set[str] = {s.lower().strip() for s in predicted}
    exp_set: Set[str] = {s.lower().strip() for s in expected}
    tp = len(pred_set & exp_set)
    precision = tp / len(pred_set)
    recall = tp / len(exp_set)
    if precision + recall == 0:
        return 0.0
    return 2 * precision * recall / (precision + recall)


class KnowledgeGraphEvaluator(BaseEvaluator):
    dimension = "knowledge_graph"

    def evaluate(self, inputs: List[KGInput]) -> List[EvalResult]:
        results: List[EvalResult] = []
        for inp in inputs:
            results.append(self._kg_query_accuracy(inp))
            if inp.expected_entities is not None and inp.extracted_entities is not None:
                results.append(self._entity_f1(inp))
            if inp.expected_relations is not None and inp.extracted_relations is not None:
                results.append(self._relation_f1(inp))
            if inp.kg_schema:
                results.append(self._schema_adherence(inp))
        return results

    def _kg_query_accuracy(self, inp: KGInput) -> EvalResult:
        return self._result("kg_query_accuracy", self.judge.score("kg_query_accuracy", {
            "natural_language_query": inp.natural_language_query,
            "kg_query": inp.kg_query,
            "kg_result": str(inp.kg_result)[:600],
        }))

    def _entity_f1(self, inp: KGInput) -> EvalResult:
        score = _f1(inp.extracted_entities, inp.expected_entities)
        return EvalResult(
            metric="entity_f1",
            score=round(score, 3),
            passed=score >= self.config.pass_threshold,
            reasoning="F1 over extracted vs. expected entities.",
            metadata={"extracted": inp.extracted_entities, "expected": inp.expected_entities},
        )

    def _relation_f1(self, inp: KGInput) -> EvalResult:
        score = _f1(inp.extracted_relations, inp.expected_relations)
        return EvalResult(
            metric="relation_f1",
            score=round(score, 3),
            passed=score >= self.config.pass_threshold,
            reasoning="F1 over extracted vs. expected relations.",
        )

    def _schema_adherence(self, inp: KGInput) -> EvalResult:
        return self._result("schema_adherence", self.judge.score("schema_adherence", {
            "kg_query": inp.kg_query,
            "schema": inp.kg_schema,
        }))
