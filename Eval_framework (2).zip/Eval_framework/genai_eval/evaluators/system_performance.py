"""
System Performance evaluator — all metrics are algorithmic (no LLM judge).
Metrics: latency_p99, error_rate, cache_hit_rate, cost_per_query,
         token_efficiency, cold_start_latency
"""
from __future__ import annotations

import statistics
from typing import List

from genai_eval.evaluators.base import BaseEvaluator
from genai_eval.schemas.inputs import PerfSample
from genai_eval.schemas.outputs import EvalResult

# SLA targets — tune these for your system
P99_SLA_MS       = 5_000.0
COLD_START_SLA   = 3_000.0
CACHE_HIT_TARGET = 0.30     # 30% hit rate target
ERROR_RATE_MAX   = 0.05     # 5% max error rate
COST_MAX_USD     = 0.05     # $0.05 max per query
TOK_PER_DOLLAR   = 10_000   # token efficiency baseline


class SystemPerformanceEvaluator(BaseEvaluator):
    dimension = "system_performance"

    def evaluate(self, inputs: List[PerfSample]) -> List[EvalResult]:
        if not inputs:
            return []
        results = [
            self._latency_p99(inputs),
            self._error_rate(inputs),
            self._cache_hit_rate(inputs),
            self._cost_per_query(inputs),
            self._token_efficiency(inputs),
        ]
        cold = [s for s in inputs if s.cold_start]
        if cold:
            results.append(self._cold_start_latency(cold))
        return results

    def _latency_p99(self, s: List[PerfSample]) -> EvalResult:
        p99 = sorted(x.latency_ms for x in s)[max(0, int(len(s) * 0.99) - 1)]
        score = max(0.0, 1.0 - p99 / P99_SLA_MS)
        return EvalResult(
            metric="latency_p99",
            score=round(score, 3),
            passed=p99 <= P99_SLA_MS,
            reasoning=f"p99 latency: {p99:.0f} ms (SLA: {P99_SLA_MS:.0f} ms).",
            metadata={"p99_ms": p99},
        )

    def _error_rate(self, s: List[PerfSample]) -> EvalResult:
        rate = sum(1 for x in s if x.error) / len(s)
        score = max(0.0, 1.0 - rate / ERROR_RATE_MAX)
        return EvalResult(
            metric="error_rate",
            score=round(score, 3),
            passed=rate <= ERROR_RATE_MAX,
            reasoning=f"Error rate: {rate:.1%} (max: {ERROR_RATE_MAX:.1%}).",
            metadata={"error_rate": round(rate, 4)},
        )

    def _cache_hit_rate(self, s: List[PerfSample]) -> EvalResult:
        rate = sum(1 for x in s if x.cache_hit) / len(s)
        score = min(1.0, rate / CACHE_HIT_TARGET)
        return EvalResult(
            metric="cache_hit_rate",
            score=round(score, 3),
            passed=rate >= CACHE_HIT_TARGET,
            reasoning=f"Cache hit rate: {rate:.1%} (target: {CACHE_HIT_TARGET:.1%}).",
            metadata={"hit_rate": round(rate, 4)},
        )

    def _cost_per_query(self, s: List[PerfSample]) -> EvalResult:
        avg = statistics.mean(x.cost_usd for x in s)
        score = max(0.0, 1.0 - avg / COST_MAX_USD)
        return EvalResult(
            metric="cost_per_query",
            score=round(score, 3),
            passed=avg <= COST_MAX_USD,
            reasoning=f"Avg cost: ${avg:.4f} / query (max: ${COST_MAX_USD}).",
            metadata={"avg_cost_usd": round(avg, 5)},
        )

    def _token_efficiency(self, s: List[PerfSample]) -> EvalResult:
        non_zero = [x for x in s if x.cost_usd > 0]
        if not non_zero:
            return EvalResult(metric="token_efficiency", score=1.0, passed=True,
                              reasoning="No cost data available.")
        tpd = statistics.mean(x.tokens_used / x.cost_usd for x in non_zero)
        score = min(1.0, tpd / TOK_PER_DOLLAR)
        return EvalResult(
            metric="token_efficiency",
            score=round(score, 3),
            passed=tpd >= TOK_PER_DOLLAR,
            reasoning=f"Token efficiency: {tpd:,.0f} tok/$.",
            metadata={"tokens_per_dollar": round(tpd, 1)},
        )

    def _cold_start_latency(self, s: List[PerfSample]) -> EvalResult:
        avg = statistics.mean(x.latency_ms for x in s)
        score = max(0.0, 1.0 - avg / COLD_START_SLA)
        return EvalResult(
            metric="cold_start_latency",
            score=round(score, 3),
            passed=avg <= COLD_START_SLA,
            reasoning=f"Avg cold start: {avg:.0f} ms (SLA: {COLD_START_SLA:.0f} ms).",
            metadata={"avg_cold_start_ms": round(avg, 1)},
        )
