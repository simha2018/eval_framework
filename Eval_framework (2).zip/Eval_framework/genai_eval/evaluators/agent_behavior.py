"""
Agent Behavior evaluator.
Metrics: task_completion, tool_selection_accuracy, step_efficiency,
         hallucinated_actions, goal_decomposition
"""
from __future__ import annotations

from typing import List

from genai_eval.evaluators.base import BaseEvaluator
from genai_eval.schemas.inputs import AgentTrace
from genai_eval.schemas.outputs import EvalResult


class AgentBehaviorEvaluator(BaseEvaluator):
    dimension = "agent_behavior"

    def evaluate(self, inputs: List[AgentTrace]) -> List[EvalResult]:
        results: List[EvalResult] = []
        for trace in inputs:
            results.append(self._task_completion(trace))
            results.append(self._step_efficiency(trace))
            results.append(self._hallucinated_actions(trace))
            results.append(self._goal_decomposition(trace))
            if trace.tools_available:
                results.append(self._tool_selection_accuracy(trace))
        return results

    def _task_completion(self, t: AgentTrace) -> EvalResult:
        return self._result("task_completion", self.judge.score("task_completion", {
            "task": t.task,
            "final_output": t.final_output,
            "expected_output": t.expected_output,
        }))

    def _tool_selection_accuracy(self, t: AgentTrace) -> EvalResult:
        return self._result("tool_selection_accuracy", self.judge.score("tool_selection_accuracy", {
            "task": t.task,
            "available_tools": t.tools_available,
            "tools_used": t.tools_used,
        }))

    def _step_efficiency(self, t: AgentTrace) -> EvalResult:
        """
        Heuristic: compare actual steps to complexity-based estimate.
        Simple task (≤30 words) → expect ≤6 steps.
        Complex task → expect ≤12 steps.
        """
        actual = len(t.steps)
        expected = 6 if len(t.task.split()) <= 30 else 12
        if actual == 0:
            score = 0.0
        elif actual <= expected:
            score = 1.0
        else:
            score = max(0.0, 1.0 - (actual - expected) / expected)
        return EvalResult(
            metric="step_efficiency",
            score=round(score, 3),
            passed=score >= self.config.pass_threshold,
            reasoning=f"Used {actual} steps; expected ≤{expected}.",
            metadata={"actual_steps": actual, "expected_max": expected},
        )

    def _hallucinated_actions(self, t: AgentTrace) -> EvalResult:
        tool_calls = [s for s in t.steps if s.type == "tool_call"]
        if not tool_calls:
            return EvalResult(metric="hallucinated_actions", score=1.0, passed=True,
                              reasoning="No tool calls to evaluate.")
        return self._result("hallucinated_actions", self.judge.score("hallucinated_actions", {
            "task": t.task,
            "steps": [{"tool": s.tool_name, "args": s.tool_args} for s in tool_calls],
            "available_tools": t.tools_available,
        }))

    def _goal_decomposition(self, t: AgentTrace) -> EvalResult:
        return self._result("goal_decomposition", self.judge.score("goal_decomposition", {
            "task": t.task,
            "steps": [{"type": s.type, "tool": s.tool_name, "content": s.content} for s in t.steps],
        }))
