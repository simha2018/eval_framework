"""
Prompt Quality evaluator.
"""
from __future__ import annotations

from typing import List

from genai_eval.evaluators.base import BaseEvaluator
from genai_eval.schemas.inputs import PromptQualityInput
from genai_eval.schemas.outputs import EvalResult


class PromptQualityEvaluator(BaseEvaluator):
    dimension = "prompt_quality"

    def evaluate(self, inputs: List[PromptQualityInput]) -> List[EvalResult]:
        results: List[EvalResult] = []
        for inp in inputs:
            results.append(self._result("instruction_adherence", self.judge.score("instruction_following", {
                "prompt": inp.prompt, "response": inp.response,
            })))
            if inp.format_spec:
                results.append(self._result("format_compliance", self.judge.score("format_compliance", {
                    "prompt": inp.prompt,
                    "response": inp.response,
                    "format_spec": inp.format_spec,
                })))
            if inp.baseline_response:
                results.append(self._result("prompt_robustness", self.judge.score("prompt_robustness", {
                    "baseline_output": inp.baseline_response,
                    "variant_output": inp.response,
                    "prompt": inp.prompt,
                })))
        return results
