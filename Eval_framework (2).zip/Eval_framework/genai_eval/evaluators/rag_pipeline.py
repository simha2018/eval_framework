"""
RAG Pipeline evaluator.
Metrics: faithfulness, answer_relevance, context_utilization,
         answer_correctness (if ground_truth), context_recall (if ground_truth)
"""
from __future__ import annotations

from typing import List

from genai_eval.evaluators.base import BaseEvaluator
from genai_eval.schemas.inputs import RAGInput
from genai_eval.schemas.outputs import EvalResult


class RAGPipelineEvaluator(BaseEvaluator):
    dimension = "rag_pipeline"

    def evaluate(self, inputs: List[RAGInput]) -> List[EvalResult]:
        results: List[EvalResult] = []
        for inp in inputs:
            results.append(self._result("faithfulness", self.judge.score("faithfulness", {
                "question": inp.question,
                "context_chunks": inp.context_chunks,
                "answer": inp.generated_answer,
            })))
            results.append(self._result("answer_relevance", self.judge.score("answer_relevance", {
                "question": inp.question,
                "answer": inp.generated_answer,
            })))
            results.append(self._result("context_utilization", self.judge.score("context_utilization", {
                "question": inp.question,
                "context_chunks": inp.context_chunks,
                "answer": inp.generated_answer,
            })))
            if inp.ground_truth:
                results.append(self._result("answer_correctness", self.judge.score("answer_correctness", {
                    "question": inp.question,
                    "answer": inp.generated_answer,
                    "ground_truth": inp.ground_truth,
                })))
                results.append(self._result("context_recall", self.judge.score("context_recall", {
                    "question": inp.question,
                    "context_chunks": inp.context_chunks,
                    "ground_truth": inp.ground_truth,
                })))
        return results
