"""
Output schemas for eval results and reports.
"""
from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional
from uuid import uuid4

from pydantic import BaseModel, Field


class EvalResult(BaseModel):
    metric: str
    score: float               # 0.0 – 1.0
    passed: bool
    reasoning: Optional[str] = None
    metadata: Dict[str, Any] = {}
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class DimensionReport(BaseModel):
    dimension: str
    overall_score: float       # mean of metric scores
    passed: bool
    metric_results: List[EvalResult]
    judge_model: str
    num_samples: int

    @classmethod
    def from_results(
        cls,
        dimension: str,
        results: List[EvalResult],
        judge_model: str,
        pass_threshold: float = 0.7,
    ) -> "DimensionReport":
        overall = sum(r.score for r in results) / len(results) if results else 0.0
        return cls(
            dimension=dimension,
            overall_score=round(overall, 3),
            passed=overall >= pass_threshold,
            metric_results=results,
            judge_model=judge_model,
            num_samples=len(results),
        )


class EvalReport(BaseModel):
    run_id: str = Field(default_factory=lambda: str(uuid4())[:8])
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    judge_provider: str
    judge_model: str
    dimension_reports: List[DimensionReport]
    overall_score: float
    passed: bool

    @classmethod
    def from_dimension_reports(
        cls,
        reports: List[DimensionReport],
        judge_provider: str,
        judge_model: str,
        pass_threshold: float = 0.7,
    ) -> "EvalReport":
        overall = sum(r.overall_score for r in reports) / len(reports) if reports else 0.0
        return cls(
            judge_provider=judge_provider,
            judge_model=judge_model,
            dimension_reports=reports,
            overall_score=round(overall, 3),
            passed=overall >= pass_threshold,
        )

    def summary(self) -> str:
        lines = [
            f"{'='*52}",
            f"  Eval Report [{self.run_id}]",
            f"  Judge : {self.judge_provider}/{self.judge_model}",
            f"  Score : {self.overall_score:.1%}  {'PASS' if self.passed else 'FAIL'}",
            f"{'='*52}",
        ]
        for dr in self.dimension_reports:
            icon = "PASS" if dr.passed else "FAIL"
            lines.append(f"  {icon}  {dr.dimension:<28} {dr.overall_score:.1%}  ({dr.num_samples} results)")
        lines.append(f"{'='*52}")
        return "\n".join(lines)
