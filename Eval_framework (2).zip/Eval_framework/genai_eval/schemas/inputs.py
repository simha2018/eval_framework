"""
Pydantic input schemas for all 8 eval dimensions.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


# ── LLM Quality ───────────────────────────────────────────────────────────────

class LLMQualityInput(BaseModel):
    question: str
    response: str
    ground_truth: Optional[str] = None
    context: Optional[str] = None           # source doc(s) used to generate response
    response_variant: Optional[str] = None  # second response for consistency checks


# ── RAG Pipeline ──────────────────────────────────────────────────────────────

class RAGInput(BaseModel):
    question: str
    context_chunks: List[str] = Field(min_length=1)
    generated_answer: str
    ground_truth: Optional[str] = None
    retrieved_doc_ids: Optional[List[str]] = None


# ── Prompt Quality ────────────────────────────────────────────────────────────

class PromptQualityInput(BaseModel):
    prompt: str
    response: str
    format_spec: Optional[str] = None        # e.g. "JSON with keys: name, score"
    baseline_response: Optional[str] = None  # reference response for robustness/A-B eval
    variant_prompt: Optional[str] = None


# ── Agent Behavior ────────────────────────────────────────────────────────────

class AgentStep(BaseModel):
    type: str                       # human_input | ai_thinking | tool_call | tool_result | ai_final
    content: Optional[str] = None
    tool_name: Optional[str] = None
    tool_args: Optional[Dict[str, Any]] = None
    tool_result: Optional[Any] = None


class AgentTrace(BaseModel):
    """
    One agent run. Compatible with LangGraph message history.

    Quick build from LangGraph:
        trace = AgentTrace.from_langgraph_messages(task, graph_messages)

    Or from graph.invoke() result:
        from genai_eval.integrations.langgraph import trace_from_invoke_result
        trace = trace_from_invoke_result(task, result, tools_available=[...])
    """
    task: str
    steps: List[AgentStep]
    final_output: str
    tools_available: List[str] = []
    tools_used: List[str] = []
    token_count: int = 0
    latency_ms: float = 0.0
    model_used: Optional[str] = None   # e.g. "claude-sonnet-4-6" or "gpt-4o"
    expected_output: Optional[str] = None

    @classmethod
    def from_langgraph_messages(
        cls,
        task: str,
        messages: list,                        # list of LangChain BaseMessage objects
        tools_available: Optional[List[str]] = None,
        latency_ms: float = 0.0,
        token_count: int = 0,
        model_used: Optional[str] = None,
        expected_output: Optional[str] = None,
    ) -> "AgentTrace":
        """
        Convert LangGraph message history into an AgentTrace.

        Works with LangChain message types: HumanMessage, AIMessage,
        ToolMessage, FunctionMessage.
        """
        steps: List[AgentStep] = []
        tools_used: set = set()

        for msg in messages:
            msg_type = getattr(msg, "type", type(msg).__name__.lower().replace("message", ""))

            if msg_type in ("human",):
                steps.append(AgentStep(type="human_input", content=str(msg.content)))

            elif msg_type in ("ai",):
                tool_calls = getattr(msg, "tool_calls", []) or []
                for tc in tool_calls:
                    name = tc.get("name") or tc.get("function", {}).get("name", "unknown")
                    args = tc.get("args") or tc.get("function", {}).get("arguments", {})
                    steps.append(AgentStep(type="tool_call", tool_name=name, tool_args=args))
                    tools_used.add(name)
                if not tool_calls and msg.content:
                    steps.append(AgentStep(type="ai_thinking", content=str(msg.content)))

            elif msg_type in ("tool", "function"):
                steps.append(AgentStep(
                    type="tool_result",
                    tool_name=getattr(msg, "name", None),
                    tool_result=msg.content,
                ))

        # final output = last AI message with content
        final_output = ""
        for msg in reversed(messages):
            if getattr(msg, "type", "") == "ai" and msg.content:
                final_output = str(msg.content)
                break

        return cls(
            task=task,
            steps=steps,
            final_output=final_output,
            tools_available=tools_available or [],
            tools_used=list(tools_used),
            token_count=token_count,
            latency_ms=latency_ms,
            model_used=model_used,
            expected_output=expected_output,
        )


# ── Multi-Agent ───────────────────────────────────────────────────────────────

class AgentCall(BaseModel):
    agent_name: str
    input: str
    output: str
    latency_ms: float = 0.0
    token_count: int = 0


class MultiAgentTrace(BaseModel):
    """One full multi-agent orchestration run (e.g. LangGraph with ~20 agents)."""
    task: str
    orchestrator: str
    agent_calls: List[AgentCall]
    final_output: str
    expected_output: Optional[str] = None
    handoff_contexts: Optional[List[Dict[str, Any]]] = None


# ── Knowledge Graph ───────────────────────────────────────────────────────────

class KGInput(BaseModel):
    natural_language_query: str
    kg_query: str                               # SPARQL / Cypher / etc.
    kg_result: Any
    kg_schema: Optional[Dict[str, Any]] = None  # entity types, relation types
    expected_entities: Optional[List[str]] = None
    expected_relations: Optional[List[str]] = None
    extracted_entities: Optional[List[str]] = None
    extracted_relations: Optional[List[str]] = None


# ── Safety ────────────────────────────────────────────────────────────────────

class SafetyInput(BaseModel):
    prompt: str
    response: str
    # attack_type=None means benign (tests over-refusal)
    attack_type: Optional[str] = None   # "jailbreak" | "injection" | None
    contains_pii: bool = False


# ── System Performance ────────────────────────────────────────────────────────

class PerfSample(BaseModel):
    agent_name: Optional[str] = None
    latency_ms: float
    tokens_used: int
    cost_usd: float
    cache_hit: bool = False
    error: bool = False
    cold_start: bool = False
