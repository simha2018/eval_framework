"""
EvalHarness — orchestrates all 8 dimension evaluators.

Usage:
    from genai_eval import EvalHarness, EvalConfig, RAGInput, AgentTrace, SafetyInput

    harness = EvalHarness(EvalConfig(judge_provider="anthropic"))
    report  = harness.evaluate(
        rag=[RAGInput(...)],
        agent=[AgentTrace(...)],
        safety=[SafetyInput(...)],
    )
    print(report.summary())
"""
from __future__ import annotations

from typing import List, Optional

from genai_eval.config import EvalConfig
from genai_eval.evaluators.agent_behavior import AgentBehaviorEvaluator
from genai_eval.evaluators.knowledge_graph import KnowledgeGraphEvaluator
from genai_eval.evaluators.llm_quality import LLMQualityEvaluator
from genai_eval.evaluators.multi_agent import MultiAgentEvaluator
from genai_eval.evaluators.prompt_quality import PromptQualityEvaluator
from genai_eval.evaluators.rag_pipeline import RAGPipelineEvaluator
from genai_eval.evaluators.safety import SafetyEvaluator
from genai_eval.evaluators.system_performance import SystemPerformanceEvaluator
from genai_eval.judges.llm_judge import LLMJudge
from genai_eval.models.factory import build_provider
from genai_eval.schemas.outputs import DimensionReport, EvalReport


class EvalHarness:
    """
    Main entry point.

    Switch judge model by changing EvalConfig:
        EvalConfig(judge_provider="anthropic", anthropic_model="claude-opus-4-6")
        EvalConfig(judge_provider="openai",    openai_model="gpt-4o")

    Run only specific dimensions:
        EvalConfig(active_dimensions=["rag", "agent", "safety"])
    """

    def __init__(self, config: Optional[EvalConfig] = None) -> None:
        self.config = config or EvalConfig()
        provider = build_provider(self.config)
        self.judge = LLMJudge(provider, pass_threshold=self.config.pass_threshold)

        self._ev = {
            "llm_quality":  LLMQualityEvaluator(self.judge, self.config),
            "rag":           RAGPipelineEvaluator(self.judge, self.config),
            "prompt":        PromptQualityEvaluator(self.judge, self.config),
            "agent":         AgentBehaviorEvaluator(self.judge, self.config),
            "multi_agent":   MultiAgentEvaluator(self.judge, self.config),
            "kg":            KnowledgeGraphEvaluator(self.judge, self.config),
            "safety":        SafetyEvaluator(self.judge, self.config),
            "perf":          SystemPerformanceEvaluator(self.judge, self.config),
        }

    def evaluate(
        self,
        llm_quality: Optional[list] = None,
        rag: Optional[list] = None,
        prompt: Optional[list] = None,
        agent: Optional[list] = None,
        multi_agent: Optional[list] = None,
        kg: Optional[list] = None,
        safety: Optional[list] = None,
        perf: Optional[list] = None,
    ) -> EvalReport:
        """
        Supply data for whichever dimensions you want to evaluate.
        Dimensions with no data are skipped automatically.
        """
        data = {
            "llm_quality": llm_quality or [],
            "rag":          rag or [],
            "prompt":       prompt or [],
            "agent":        agent or [],
            "multi_agent":  multi_agent or [],
            "kg":           kg or [],
            "safety":       safety or [],
            "perf":         perf or [],
        }
        if self.config.active_dimensions:
            data = {k: v for k, v in data.items() if k in self.config.active_dimensions}

        reports: List[DimensionReport] = []
        for key, inputs in data.items():
            if not inputs:
                continue
            ev = self._ev[key]
            results = ev.evaluate(inputs)
            if results:
                reports.append(ev.report(results))

        return EvalReport.from_dimension_reports(
            reports=reports,
            judge_provider=str(self.config.judge_provider),
            judge_model=self.config.active_judge_model,
            pass_threshold=self.config.pass_threshold,
        )
