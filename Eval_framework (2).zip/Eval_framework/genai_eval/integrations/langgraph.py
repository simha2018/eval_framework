"""
LangGraph integration helpers.

Two patterns:

1. From graph.invoke() result (no checkpointer needed):
    from genai_eval.integrations.langgraph import trace_from_invoke_result
    result = graph.invoke({"messages": [HumanMessage(content=task)]})
    trace = trace_from_invoke_result(task, result, tools_available=[...])

2. From state history (requires checkpointer):
    from genai_eval.integrations.langgraph import traces_from_graph_history
    traces = traces_from_graph_history(graph, config, task)
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from genai_eval.schemas.inputs import AgentTrace


def trace_from_invoke_result(
    task: str,
    result: Dict[str, Any],         # dict returned by graph.invoke()
    tools_available: Optional[List[str]] = None,
    expected_output: Optional[str] = None,
    model_used: Optional[str] = None,
    latency_ms: float = 0.0,
    token_count: int = 0,
) -> AgentTrace:
    """
    Build an AgentTrace from a graph.invoke() result.
    Works without a checkpointer — pass the result dict directly.

    Example:
        result = graph.invoke({"messages": [HumanMessage(content=task)]})
        trace = trace_from_invoke_result(
            task=task,
            result=result,
            tools_available=["planisware_get_project", "cdocs_search", "kg_query"],
            model_used="claude-sonnet-4-6",
            latency_ms=1500.0,
        )
    """
    messages = result.get("messages", [])
    return AgentTrace.from_langgraph_messages(
        task=task,
        messages=messages,
        tools_available=tools_available,
        expected_output=expected_output,
        model_used=model_used,
        latency_ms=latency_ms,
        token_count=token_count,
    )


def traces_from_graph_history(
    graph: Any,                     # CompiledStateGraph with checkpointer
    config: Dict[str, Any],         # {"configurable": {"thread_id": "..."}}
    task: str,
    tools_available: Optional[List[str]] = None,
    expected_output: Optional[str] = None,
    model_used: Optional[str] = None,
) -> List[AgentTrace]:
    """
    Build AgentTrace objects from LangGraph checkpoint state history.
    Requires a checkpointer-backed graph (MemorySaver, SqliteSaver, etc.).

    Example:
        from langgraph.checkpoint.memory import MemorySaver
        graph = workflow.compile(checkpointer=MemorySaver())
        graph.invoke({"messages": [...]}, config={"configurable": {"thread_id": "t1"}})

        traces = traces_from_graph_history(
            graph, {"configurable": {"thread_id": "t1"}}, task
        )
    """
    try:
        history = list(graph.get_state_history(config))
    except Exception as e:
        raise RuntimeError(
            "Could not read state history. Ensure graph has a checkpointer. "
            f"Error: {e}"
        ) from e

    if not history:
        return []

    # Most recent checkpoint first
    latest = history[0]
    messages = latest.values.get("messages", [])
    if not messages:
        return []

    return [AgentTrace.from_langgraph_messages(
        task=task,
        messages=messages,
        tools_available=tools_available,
        expected_output=expected_output,
        model_used=model_used,
    )]


def build_perf_sample_from_run_metadata(metadata: Dict[str, Any]):
    """
    Helper to build a PerfSample from LangSmith run metadata or
    LangGraph's usage_metadata dict.

    Expected keys: latency_ms, tokens_used (or input_tokens+output_tokens),
                   cost_usd (or approximate), cache_hit, error, cold_start, agent_name.
    """
    from genai_eval.schemas.inputs import PerfSample
    tokens = metadata.get("tokens_used") or (
        metadata.get("input_tokens", 0) + metadata.get("output_tokens", 0)
    )
    return PerfSample(
        agent_name=metadata.get("agent_name"),
        latency_ms=metadata.get("latency_ms", 0.0),
        tokens_used=tokens,
        cost_usd=metadata.get("cost_usd", 0.0),
        cache_hit=metadata.get("cache_hit", False),
        error=metadata.get("error", False),
        cold_start=metadata.get("cold_start", False),
    )
