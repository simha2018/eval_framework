"""
Example: RAG pipeline evaluation — compare Claude vs GPT judge scores.

Run:
    cd genai_eval
    pip install -e .
    ANTHROPIC_API_KEY=sk-... OPENAI_API_KEY=sk-... python examples/eval_rag.py
"""
from genai_eval import EvalConfig, EvalHarness, JudgeProvider, RAGInput
from genai_eval.reporters.report import print_summary, save_json, save_markdown

SAMPLES = [
    RAGInput(
        question="What is the purpose of Planisware in our organization?",
        context_chunks=[
            "Planisware is a Project Portfolio Management (PPM) platform used to plan, "
            "prioritize, and track R&D and IT projects across the organization.",
            "It provides resource management, financial forecasting, and project scheduling.",
        ],
        generated_answer=(
            "Planisware is our PPM platform for managing R&D and IT project portfolios, "
            "covering resource management and financial planning."
        ),
        ground_truth=(
            "Planisware is used for planning, prioritizing, and tracking R&D and IT "
            "projects, with resource management and financial forecasting features."
        ),
    ),
    RAGInput(
        question="How many specialized agents does the multi-agent system have?",
        context_chunks=[
            "The Gen AI team has built a LangGraph-based multi-agent architecture "
            "with approximately 20 specialized agents.",
        ],
        generated_answer="The system has around 20 specialized LangGraph agents.",
        ground_truth="Approximately 20 specialized agents.",
    ),
    RAGInput(
        question="What document store is integrated with the platform?",
        context_chunks=[
            "The Knowledge Graph layer integrates with CDocs, the corporate document store.",
            "CDocs holds all project documentation, contracts, and compliance records.",
        ],
        generated_answer="The platform integrates with CDocs, the corporate document store.",
        ground_truth="CDocs is the integrated document store.",
    ),
]


def main():
    # ── Claude as judge ──────────────────────────────────────────────────────
    print("\n[1/2] Evaluating with Claude (claude-sonnet-4-6) as judge...")
    claude_harness = EvalHarness(EvalConfig(
        judge_provider=JudgeProvider.ANTHROPIC,
        anthropic_model="claude-sonnet-4-6",
    ))
    claude_report = claude_harness.evaluate(rag=SAMPLES)
    print_summary(claude_report)
    save_json(claude_report, "rag_eval_claude.json")
    save_markdown(claude_report, "rag_eval_claude.md")

    # ── GPT-4o as judge ──────────────────────────────────────────────────────
    print("\n[2/2] Evaluating with GPT-4o as judge...")
    gpt_harness = EvalHarness(EvalConfig(
        judge_provider=JudgeProvider.OPENAI,
        openai_model="gpt-4o",
    ))
    gpt_report = gpt_harness.evaluate(rag=SAMPLES)
    print_summary(gpt_report)
    save_json(gpt_report, "rag_eval_gpt.json")


if __name__ == "__main__":
    main()
