"""
Example: Multi-agent orchestration evaluation.
Models the team's LangGraph architecture: orchestrator → specialized agents
(planisware_agent, cdocs_agent, kg_query_agent, report_generation_agent, ...).

Run:
    ANTHROPIC_API_KEY=sk-... python examples/eval_multi_agent.py
"""
from genai_eval import AgentCall, EvalConfig, EvalHarness, JudgeProvider, MultiAgentTrace
from genai_eval.reporters.report import print_summary, save_markdown


def build_portfolio_report_trace() -> MultiAgentTrace:
    return MultiAgentTrace(
        task="Generate a Q3 portfolio health report from Planisware data and relevant CDocs.",
        orchestrator="orchestrator_agent",
        agent_calls=[
            AgentCall(
                agent_name="planisware_agent",
                input="Retrieve all active projects with Q3 status and KPIs",
                output="12 active projects retrieved: 8 on track, 3 at risk, 1 delayed.",
                latency_ms=1800.0,
                token_count=420,
            ),
            AgentCall(
                agent_name="cdocs_agent",
                input="Find Q3 portfolio review template and risk management guidelines",
                output="Found: Q3_Review_Template.docx, Risk_Management_Guidelines_v3.pdf",
                latency_ms=900.0,
                token_count=210,
            ),
            AgentCall(
                agent_name="kg_query_agent",
                input="Get risk relationships and dependencies for at-risk projects",
                output="Risk graph: ProjectB→resource_constraint, ProjectD→dependency_delay, ProjectF→budget_overrun",
                latency_ms=600.0,
                token_count=180,
            ),
            AgentCall(
                agent_name="report_generation_agent",
                input="Generate Q3 portfolio health report using retrieved Planisware data, CDocs templates, and KG risk data",
                output=(
                    "Q3 Portfolio Health Report: 12 projects — 8 on track (67%), "
                    "3 at risk (25%), 1 delayed (8%). Key risks: resource constraints on ProjectB, "
                    "dependency delays on ProjectD, budget overrun on ProjectF."
                ),
                latency_ms=2400.0,
                token_count=850,
            ),
        ],
        final_output=(
            "Q3 Portfolio Health Report generated. 12 projects reviewed: "
            "8 on track (67%), 3 at risk (25%), 1 delayed (8%). "
            "Key risks documented with mitigation recommendations from risk guidelines."
        ),
        expected_output=(
            "A Q3 portfolio health report covering all active projects with "
            "risk breakdown and mitigation guidance."
        ),
    )


def main():
    print("\n=== Multi-Agent Orchestration Evaluation ===")

    trace = build_portfolio_report_trace()

    harness = EvalHarness(EvalConfig(
        judge_provider=JudgeProvider.ANTHROPIC,
        anthropic_model="claude-sonnet-4-6",
    ))
    report = harness.evaluate(multi_agent=[trace])
    print_summary(report)
    save_markdown(report, "multi_agent_eval.md")


if __name__ == "__main__":
    main()
