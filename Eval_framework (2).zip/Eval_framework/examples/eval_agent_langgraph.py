"""
Example: Evaluate a LangGraph agent.

Two patterns shown:
  1. Manual AgentTrace — works with any agent, no graph required
  2. trace_from_invoke_result — pass graph.invoke() output directly

Run:
    ANTHROPIC_API_KEY=sk-... python examples/eval_agent_langgraph.py
"""
from genai_eval import AgentStep, AgentTrace, EvalConfig, EvalHarness, JudgeProvider
from genai_eval.reporters.report import print_summary, save_markdown


# ── Pattern 1: Manual AgentTrace ─────────────────────────────────────────────
def eval_planisware_agent():
    """Manually construct a trace — works for any agent framework."""
    trace = AgentTrace(
        task="Find the status of Project Alpha in Planisware and summarize it.",
        steps=[
            AgentStep(type="human_input",
                      content="Find the status of Project Alpha in Planisware and summarize it."),
            AgentStep(type="tool_call",
                      tool_name="planisware_get_project",
                      tool_args={"project_name": "Project Alpha"}),
            AgentStep(type="tool_result",
                      tool_name="planisware_get_project",
                      tool_result={"status": "On Track", "completion": "65%", "budget_variance": "-2%"}),
            AgentStep(type="ai_final",
                      content="Project Alpha is On Track at 65% completion with a 2% budget underrun."),
        ],
        final_output="Project Alpha is On Track at 65% completion with a 2% budget underrun.",
        tools_available=["planisware_get_project", "planisware_list_projects", "cdocs_search"],
        tools_used=["planisware_get_project"],
        latency_ms=1200.0,
        token_count=380,
        model_used="claude-sonnet-4-6",
        expected_output="Project Alpha is on track at 65% with a 2% budget underrun.",
    )
    return trace


# ── Pattern 2: From graph.invoke() ───────────────────────────────────────────
def eval_from_graph_invoke():
    """
    Integrate directly with your LangGraph graph.
    Replace the commented block with your actual graph.
    """
    from genai_eval.integrations.langgraph import trace_from_invoke_result

    # ── Uncomment and adapt for your actual graph: ─────────────────────────
    #
    # from langchain_core.messages import HumanMessage
    # from your_app.graph import build_graph
    #
    # graph = build_graph()
    # task = "Find the status of Project Alpha"
    #
    # result = graph.invoke(
    #     {"messages": [HumanMessage(content=task)]},
    #     config={"configurable": {"thread_id": "eval-001"}}
    # )
    #
    # trace = trace_from_invoke_result(
    #     task=task,
    #     result=result,
    #     tools_available=["planisware_get_project", "cdocs_search", "kg_query"],
    #     model_used="gpt-4o",
    #     latency_ms=1800.0,
    # )
    # return trace
    # ───────────────────────────────────────────────────────────────────────

    print("  → Pattern 2: Uncomment the graph.invoke() block to use with your actual graph.")
    return None


def main():
    print("\n=== Agent Behavior Evaluation ===")

    trace1 = eval_planisware_agent()
    trace2 = eval_from_graph_invoke()

    traces = [t for t in [trace1, trace2] if t is not None]

    harness = EvalHarness(EvalConfig(
        judge_provider=JudgeProvider.ANTHROPIC,
        anthropic_model="claude-sonnet-4-6",
    ))
    report = harness.evaluate(agent=traces)
    print_summary(report)
    save_markdown(report, "agent_eval.md")


if __name__ == "__main__":
    main()
